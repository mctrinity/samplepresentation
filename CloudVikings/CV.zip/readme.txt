Thank you for your recent logo file purchase. Please find a short description of the different file types located in your folder.

JPG: These logo files have a white background or white box as your logo background.

PNG: These logo files allow for transparency, so they do not have a white box/background. You would want to use these files when you are uploading your logo to a website or placing it in a file that has a background color or pattern other than white that you would to show behind your logo.

.EPS: (Encapsulated PostScript)- This file is for printer/designer use. These files have been supplied to you with your logo image and your logo and fonts as shapes. 

.SVG: (Scalable Vector Graphics)- These files are for printer/designer use. These files are the original design files which include the fonts used in your logo as well.

.PDF: (Portable Document Format) - This file is used to preserve the layout of your logo format on all computer and mobile devices. Can sometimes be an acceptable format for printers.

dpi: Dots per inch: a measure of resolution used for printed text or images, the more dots per inch, the higher the resolution.

px: Pixels: a minute area of illumination on a display screen, one of many from which an image is composed.

